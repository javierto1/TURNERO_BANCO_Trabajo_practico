-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 14-07-2015 a las 13:02:33
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `turnos`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `caja`
-- 

CREATE TABLE `caja` (
  `id_caja` int(11) NOT NULL,
  `numero_caja` char(2) NOT NULL,
  PRIMARY KEY  (`id_caja`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `caja`
-- 

INSERT INTO `caja` VALUES (1, '1');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `num_turno`
-- 

CREATE TABLE `num_turno` (
  `id_num_turno` int(11) NOT NULL auto_increment,
  `numero` int(3) NOT NULL,
  `letra` char(3) NOT NULL,
  `estado` varchar(10) NOT NULL default 'pendiente',
  `caja` varchar(3) default NULL,
  `fecha_turno` varchar(10) default NULL,
  `hora_solicitado` varchar(10) default NULL,
  `hora_atendido` varchar(10) NOT NULL,
  `hora_finalizado` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_num_turno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `num_turno`
-- 

